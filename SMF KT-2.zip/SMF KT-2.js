const express = require('express');
const xlsx = require('xlsx');
const cron = require('node-cron');
const sql = require('mssql');
const SftpClient = require('ssh2-sftp-client');
const scfKey = 'SCF Transaction No.';
const path = require('path');

// ----------------------------------------------------
// MSSQL Configuration
// ----------------------------------------------------
const dbConfig = {
  user: 'smf',
  password: '123456Smf!',
  server: 'smf-database.cj8g2o6war11.ap-southeast-2.rds.amazonaws.com',
  database: 'smf-gec',
  options: {
    encrypt: true,
    trustServerCertificate: true,
    connectTimeout: 30000,
    requestTimeout: 300000
  }
};


// ----------------------------------------------------
// SFTP Configuration & Remote Paths
// ----------------------------------------------------
const sftpConfig = {
  host: '27.254.97.29',
  port: 22,
  username: 'selfmadeagent',
  password: 'Ox6A7RI=FQ'
};
// ----------------------------------------------------
const sftpSMFConfig = {
  host: '13.212.148.153',
  port: 22,
  username: 'smfuser',
  password: 'smf@2025'
};
const remoteRequestDir = 'Transaction_Request';
const remoteResultDir = 'Transaction_Result';

const sftp = new SftpClient();
const sftpSMF = new SftpClient();
let pool;

// ----------------------------------------------------
// Singleton SQL connection pool
// ----------------------------------------------------
async function getPool() {
  // กรณี pool ยังไม่สร้าง หรือ pool ถูกปิดไปแล้ว (connected=false) ให้เชื่อมต่อใหม่
  if (!pool || !pool.connected) {
    pool = await sql.connect(dbConfig);
    // ขยาย listener limit
    pool.setMaxListeners(40);
    pool.on('error', err => {
      console.error('SQL Pool Error', err);
    });
  }
  return pool;
}

// ----------------------------------------------------
// Helper Functions (parse & format)
// ----------------------------------------------------
function getString(value) {
  return value != null ? value.toString().trim() : '';
}
function parseExcelDate(dateValue) {
  if (!dateValue) return null;
  if (typeof dateValue === 'number') {
    const dateInMillis = (dateValue - 25569) * 86400 * 1000;
    const tmp = new Date(dateInMillis);
    return new Date(Date.UTC(tmp.getUTCFullYear(), tmp.getUTCMonth(), tmp.getUTCDate()));
  }
  if (typeof dateValue === 'string' && dateValue.includes('/')) {
    const [d, m, y] = dateValue.split('/').map(n => parseInt(n, 10));
    return new Date(Date.UTC(y, m - 1, d));
  }
  const parsed = new Date(dateValue);
  return isNaN(parsed.getTime()) ? null :
    new Date(Date.UTC(parsed.getFullYear(), parsed.getMonth(), parsed.getDate()));
}
function parseNumber(value) {
  const v = parseInt(value, 10);
  return isNaN(v) ? null : v;
}
function parseDecimal(value) {
  const v = parseFloat(value);
  if (isNaN(v)) return null;
  return Math.round(v * 100) / 100;
}
function parseTime(timeString) {
  if (!timeString) return null;
  if (typeof timeString === 'number') {
    const totalSec = Math.round(timeString * 86400);
    const hh = Math.floor(totalSec / 3600);
    const mm = Math.floor((totalSec % 3600) / 60);
    const ss = totalSec % 60;
    return new Date(Date.UTC(1970, 0, 1, hh, mm, ss));
  }
  const [timePart, ampm] = timeString.split(' ');
  let [h, m, s] = timePart.split(':').map(n => parseInt(n, 10) || 0);
  if (ampm === 'PM' && h < 12) h += 12;
  if (ampm === 'AM' && h === 12) h = 0;
  return new Date(Date.UTC(1970, 0, 1, h, m, s));
}

// ----------------------------------------------------
// SFTP-based file operations
// ----------------------------------------------------
async function getFileBuffer(fileName) {
  const remotePath = `${remoteRequestDir}/${fileName}`;
  try {
    const buf = await sftp.get(remotePath);
    return buf;
  } catch (err) {
    console.error(`Error getting file buffer for ${fileName}:`, err);
    throw err;
  }
}

async function putFileBuffer(buffer, fileName) {
  const remotePath = `${remoteResultDir}/${fileName}`;
  const remoteSMFPath = `/data/${remoteResultDir}/${fileName}`;
  try {
    await sftp.put(buffer, remotePath);
    await sftpSMF.put(buffer, remoteSMFPath);
  } catch (err) {
    console.error(`Error putting file buffer ${fileName}:`, err);
    throw err;
  }
}

async function renameRemoteFile(oldName, newName) {
  const oldPath = `${remoteRequestDir}/${oldName}`;
  const newPath = `${remoteRequestDir}/${newName}`;
  try {
    await sftp.rename(oldPath, newPath);
  } catch (err) {
    console.error(`Error renaming ${oldName} to ${newName}:`, err);
    throw err;
  }
}

// ----------------------------------------------------
// ฟังก์ชัน listRawFiles: ดึงรายชื่อไฟล์ .xlsx ที่ยังไม่ติด _Read และไม่ขึ้นต้นด้วย GEC_
// ----------------------------------------------------
async function listRawFiles() {
  if (!await sftp.exists(remoteRequestDir)) {
    console.warn(`Warning: ไม่พบโฟลเดอร์ ${remoteRequestDir} บน SFTP`);
    return [];
  }
  const files = await sftp.list(remoteRequestDir);
  return files
    .filter(f =>
      f.type === '-' &&
      f.name.toLowerCase().endsWith('.xlsx') &&
      !/_Read\.xlsx$/i.test(f.name) &&
      !/^GEC_/i.test(f.name)
    )
    .map(f => f.name);
}

// ----------------------------------------------------
// Read an Excel sheet from buffer using header row 8
// ----------------------------------------------------
function readExcelSheetFromBuffer(buffer, sheetName) {
  const wb = xlsx.read(buffer, { type: 'buffer', cellDates: true });
  if (!wb.Sheets[sheetName]) {
    console.error(`Sheet "${sheetName}" not found`);
    return [];
  }
  return xlsx.utils.sheet_to_json(wb.Sheets[sheetName], { defval: '', range: 7, raw: true })
}

// ----------------------------------------------------
// Process a single Excel file into the database
// ----------------------------------------------------
async function processExcelFile(fileName) {
  console.log(`Processing file: ${fileName}`);
  const buffer = await getFileBuffer(fileName);
  const mainData = readExcelSheetFromBuffer(buffer, 'SFP_Transaction_Request');
  const detailData = readExcelSheetFromBuffer(buffer, 'SFP_Transaction_Request_Detail');

  const pool = await getPool();
  for (const row of mainData) {
    const scfNo = getString(row[scfKey]);
    if (!scfNo) {
      console.error('Missing SCF Transaction No., skipping row');
      continue;
    }

    // Lookup supplier
    let reasonCode = '02';
    let reason = 'No Supplier Found';
    try {
      const clientRes = await pool.request()
        .input('supplierID', sql.NVarChar(50), getString(row['Supplier Customer ID']))
        .query('SELECT TOP 1 sys_id FROM dbo.clienttbl WHERE link_cli = @supplierID');
      if (clientRes.recordset.length) {
        reasonCode = 'FW';
        reason = 'Wait for Factoring';
      }
    } catch (err) {
      console.error(`Error looking up supplier for ${scfNo}:`, err);
    }

    // Check duplicates
    try {
      const dupRes = await pool.request()
        .input('scfNo', sql.NVarChar(50), scfNo)
        .query('SELECT 1 FROM dbo.SCF_Transactions WHERE SCF_Transaction_No = @scfNo');
      if (dupRes.recordset.length) {
        console.log(`Skipping duplicate: ${scfNo}`);
        continue;
      }
    } catch (err) {
      console.error(`Error checking duplicate for ${scfNo}:`, err);
    }

    // Insert main record
    try {
      const req = pool.request();
      req.input('Sponsor', sql.NVarChar(100), getString(row['Sponsor']));
      req.input('Supplier', sql.NVarChar(100), getString(row['Supplier']));
      req.input('Sponsor_Customer_ID', sql.NVarChar(50), getString(row['Sponsor Customer ID']));
      req.input('Supplier_Customer_ID', sql.NVarChar(50), getString(row['Supplier Customer ID']));
      req.input('SCF_Transaction_No', sql.NVarChar(50), scfNo);
      req.input('Transaction_Date', sql.Date, parseExcelDate(row['Transaction Date']));
      req.input('Maturity_Date', sql.Date, parseExcelDate(row['Maturity Date']));
      req.input('Sponsor_Payment_Date', sql.Date, parseExcelDate(row['Sponsor Payment Date']));
      req.input('Tenor', sql.Int, parseNumber(row['Tenor']));
      req.input('Interest_Rate', sql.Decimal(5, 2), parseDecimal(row['Interest Rate']));
      req.input('Transaction_Amount', sql.Decimal(36, 6), parseDecimal(row['Transaction Amount']));
      req.input('Currency', sql.NVarChar(10), getString(row['Currency']));
      req.input('Transaction_Type', sql.NVarChar(20), getString(row['Transaction Type']));
      req.input('Supplier_Bank_Code_Source', sql.NVarChar(20), getString(row['Supplier Bank Code (Source)']));
      req.input('Bank_Account_No_Source', sql.NVarChar(30), getString(row['Bank Account No. (Source)']));
      req.input('Supplier_Bank_Code_Destination', sql.NVarChar(20), getString(row['Supplier Bank Code (Destination)']));
      req.input('Bank_Account_No_Destination', sql.NVarChar(30), getString(row['Bank Account No. (Destination)']));
      req.input('Remark', sql.NVarChar(255), getString(row['Remark']));
      req.input('Current_Transaction_Status', sql.NVarChar(50), getString(row['Current Transaction Status']));
      req.input('Transaction_Result_Status', sql.NVarChar(50), getString(row['Transaction Result Status']));
      req.input('Bank_Transaction_No', sql.NVarChar(50), getString(row['Bank Transaction No']));
      req.input('Bank_Transaction_Date', sql.Date, parseExcelDate(row['Bank Transaction Date']));
      req.input('Bank_Transaction_Time', sql.Time, parseTime(row['Bank Transaction Time']));
      req.input('Reason_Code', sql.NVarChar(10), reasonCode);
      req.input('Reason', sql.NVarChar(255), reason);
      req.input('adv_amt', sql.Decimal(36, 6), parseDecimal(row['adv_amt']));
      req.input('int_amt', sql.Decimal(36, 6), parseDecimal(row['int_amt']));
      req.input('ffee', sql.Decimal(36, 6), parseDecimal(row['ffee']));
      req.input('othfee', sql.Decimal(36, 6), parseDecimal(row['othfee']));
      req.input('deposit', sql.Decimal(36, 6), parseDecimal(row['deposit']));
      req.input('net_payment', sql.Decimal(36, 6), parseDecimal(row['net payment']));
      req.input('amt_i', sql.Decimal(36, 6), parseDecimal(row['amt_i']));
      req.input('wht_i', sql.Decimal(36, 6), parseDecimal(row['wht_i']));
      req.input('amt_f', sql.Decimal(36, 6), parseDecimal(row['amt_f']));
      req.input('wht_f', sql.Decimal(36, 6), parseDecimal(row['wht_f']));
      req.input('sr_no', sql.NVarChar(50), getString(row['sr_no']));
      req.input('pur_dd', sql.Date, parseExcelDate(row['pur_dd']));
      req.input('fix_col_dd', sql.Date, parseExcelDate(row['fix_col_dd']));

      await req.query(`INSERT INTO dbo.SCF_Transactions (
        Sponsor, Supplier, Sponsor_Customer_ID, Supplier_Customer_ID,
        SCF_Transaction_No, Transaction_Date, Maturity_Date,
        Sponsor_Payment_Date, Tenor, Interest_Rate, Transaction_Amount,
        Currency, Transaction_Type, Supplier_Bank_Code_Source,
        Bank_Account_No_Source, Supplier_Bank_Code_Destination,
        Bank_Account_No_Destination, Remark, Current_Transaction_Status,
        Transaction_Result_Status, Bank_Transaction_No, Bank_Transaction_Date,
        Bank_Transaction_Time, Reason_Code, Reason,
        adv_amt, int_amt, ffee, othfee, deposit, net_payment,
        amt_i, wht_i, amt_f, wht_f, sr_no, pur_dd, fix_col_dd
      ) VALUES (
        @Sponsor, @Supplier, @Sponsor_Customer_ID, @Supplier_Customer_ID,
        @SCF_Transaction_No, @Transaction_Date, @Maturity_Date,
        @Sponsor_Payment_Date, @Tenor, @Interest_Rate, @Transaction_Amount,
        @Currency, @Transaction_Type, @Supplier_Bank_Code_Source,
        @Bank_Account_No_Source, @Supplier_Bank_Code_Destination,
        @Bank_Account_No_Destination, @Remark, @Current_Transaction_Status,
        @Transaction_Result_Status, @Bank_Transaction_No, @Bank_Transaction_Date,
        @Bank_Transaction_Time, @Reason_Code, @Reason,
        @adv_amt, @int_amt, @ffee, @othfee, @deposit, @net_payment,
        @amt_i, @wht_i, @amt_f, @wht_f, @sr_no, @pur_dd, @fix_col_dd
      )`);
      console.log(`Inserted main: ${scfNo}`);
    } catch (err) {
      console.error(`Error inserting main record ${scfNo}:`, err);
      continue;
    }

    // If FW: insert into debttrn and debt_d
    if (reasonCode === 'FW') {
      let trnId;

      // 1) เช็คซ้ำก่อน
      try {
        const existRes = await pool.request()
          .input('trn_ref', sql.NVarChar(50), scfNo)
          .query(`
            SELECT 1 
            FROM dbo.debttrn 
            WHERE trn_ref = @trn_ref
          `);
        if (existRes.recordset.length) {
          console.log(`Skipping duplicate debttrn for ${scfNo}`);
        } else {
          // 2) ถ้ายังไม่ซ้ำ ให้ insert
          const debtReq = pool.request();
          debtReq.input('link_cli', sql.NVarChar(50), getString(row['Supplier Customer ID']));
          debtReq.input('link_cst', sql.NVarChar(50), getString(row['Sponsor Customer ID']));
          debtReq.input('trn_ref', sql.NVarChar(50), scfNo);
          debtReq.input('trn_dd', sql.Date, parseExcelDate(row['Transaction Date']));
          debtReq.input('trn_mature_dd', sql.Date, parseExcelDate(row['Maturity Date']));
          debtReq.input('trn_due_dd', sql.Date, parseExcelDate(row['Maturity Date']));
          // cap & round สำหรับ DECIMAL(18,2)
          const MAX_18_2 = 9999999999999999.99;
          let amt = parseDecimal(row['Transaction Amount']);
          if (amt > MAX_18_2) amt = MAX_18_2;
          amt = Math.round(amt * 100) / 100;
          debtReq.input('amount', sql.Decimal(18, 2), amt);

          const debtRes = await debtReq.query(`
            INSERT INTO dbo.debttrn (
              sys_id, link_cli, link_cst, trn_ref,
              trn_dd, trn_mature_dd, trn_due_dd,
              trn_status, trn_status_dd, trn_status_by, amount
            )
            OUTPUT INSERTED.trn_id
            VALUES (
              'GEC', @link_cli, @link_cst, @trn_ref,
              @trn_dd, @trn_mature_dd, @trn_due_dd,
              'FW', GETDATE(), 'KK', @amount
            );
          `);
          trnId = debtRes.recordset[0]?.trn_id;
          console.log(`Inserted debttrn trn_id=${trnId}`);
        }
      } catch (err) {
        console.error(`Error handling debttrn for ${scfNo}:`, err);
      }

      // Insert detail rows
      if (trnId) {
        for (const d of detailData.filter(dd => getString(dd[scfKey]) === scfNo)) {
          const docNo = getString(d['Document No.']);
          const docAmt = parseDecimal(d['Document Amount']);
          try {
            const detReq = pool.request();
            detReq.input('trn_id', sql.Int, trnId);
            detReq.input('doc_no', sql.NVarChar(50), docNo);
            detReq.input('doc_dd', sql.Date, parseExcelDate(d['Document Date']));
            detReq.input('doc_due_dd', sql.Date, parseExcelDate(d['Document Due Date']));
            detReq.input('amount', sql.Decimal(36, 6), docAmt);
            await detReq.query(`INSERT INTO dbo.debt_d (
              trn_id, doc_no, doc_dd, doc_due_dd, amount
            ) VALUES (
              @trn_id, @doc_no, @doc_dd, @doc_due_dd, @amount
            )`);
            console.log(`Inserted debt_d for trn_id=${trnId}, doc_no=${docNo}`);
          } catch (err) {
            console.error(`Error inserting debt_d for trn_id=${trnId}, doc_no=${docNo}, amount=${docAmt}:`, err);
          }
        }
      }
    }
  }
}

// ----------------------------------------------------
// Update SCF_Transactions from debttrn
// ----------------------------------------------------
async function updateSCFTransactionsFromDebttrn() {
  try {
    const pool = await getPool();
    await pool.request().query(
      `UPDATE s
       SET
         s.adv_amt     = d.adv_amt,
         s.int_amt     = d.int_amt,
         s.ffee        = d.ffee,
         s.othfee      = d.othfee,
         s.deposit     = d.deposit,
         s.net_payment = d.net_payment,
         s.amt_i       = d.amt_i,
         s.wht_i       = d.wht_i,
         s.amt_f       = d.amt_f,
         s.wht_f       = d.wht_f,
         s.sr_no       = d.sr_no,
         s.pur_dd      = d.pur_dd,
         s.fix_col_dd  = d.fix_col_dd,
         s.Reason_Code = d.trn_status,
         s.Reason      = CASE d.trn_status
                          WHEN 'FW' THEN 'Wait for Factoring'
                          WHEN 'FP0' THEN 'Start Factoring Process'
                          WHEN 'FP1' THEN 'Finish Factoring, wait for payment'
                          WHEN 'FP2' THEN 'Disbursement completed'
                          WHEN 'RJ' THEN 'Fail / Rejected'
                          ELSE s.Reason
                        END
       FROM dbo.SCF_Transactions s
       INNER JOIN dbo.debttrn d
         ON d.trn_ref COLLATE SQL_Latin1_General_CP1_CI_AS =
            s.SCF_Transaction_No COLLATE SQL_Latin1_General_CP1_CI_AS
       WHERE s.Reason_Code <> '02'`
    );
    console.log('SCF_Transactions updated from debttrn.');
  } catch (err) {
    console.error('Error updating SCF_Transactions:', err);
  }
}

// ----------------------------------------------------
// Export step: enrichment และ For Customer (แก้ไขเพิ่มคอลัมน์ใน Detail Sheet)
// ----------------------------------------------------
async function exportFiles(files) {
  const pool = await getPool();

  for (const fileName of files) {
    const baseName = fileName.replace(/\.xlsx$/i, '');

    // 1) โหลด workbook เต็ม (ทั้ง Main + Detail) จากไฟล์ต้นทาง
    const wbFull = xlsx.read(await getFileBuffer(fileName), { type: 'buffer', cellDates: true });
    const mainName = 'SFP_Transaction_Request';
    const detailName = 'SFP_Transaction_Request_Detail';

    // --------- 2) ทำ Enrichment สำหรับชีท Detail: เพิ่มคอลัมน์ amount, advance และ dentry ---------
    // 2.1 ตรวจว่า sheet Detail มีอยู่จริง
    const detailSheetOriginal = wbFull.Sheets[detailName];
    if (!detailSheetOriginal) {
      console.warn(`Sheet "${detailName}" ไม่พบในไฟล์ ${fileName}`);
    } else {
      // 2.2 อ่านข้อมูล JSON จากชีทต้นทาง (ข้าม 7 แถวหัว)
      const detailRowsRaw = xlsx.utils.sheet_to_json(detailSheetOriginal, { defval: '', range: 7 });
      if (detailRowsRaw.length === 0) {
        console.log(`ไม่มีข้อมูลในชีท "${detailName}" หลังจาก range:7`);
      } else {
        // 2.3 ดึง header ดั้งเดิมจาก detailRowsRaw[0]
        const origHeader = Object.keys(detailRowsRaw[0] || []);
        console.log('origHeader (Detail):', origHeader);

        // 2.4 สร้าง newHeader โดยต่อท้าย ['amount','advance','dentry']
        const newHeader = [...origHeader, 'amount', 'advance', 'dentry'];
        console.log('newHeader (Detail):', newHeader);

        // 2.5 วนลูปทุกแถว เพื่อดึงค่า amount, advance, dentry จาก debt_d
        for (const row of detailRowsRaw) {
          const scfNo = getString(row[scfKey]);        // SCF Transaction No.
          const docNo = getString(row['Document No']); // Document No
          let amountVal = '';
          let advanceVal = '';
          let dentryVal = '';

          if (scfNo && docNo) {
            try {
              // Query ดึงทั้ง 3 ฟิลด์จาก debt_d (join ผ่าน debttrn)
              const resD = await pool.request()
                .input('scfNo', sql.NVarChar(50), scfNo)
                .input('docNo', sql.NVarChar(50), docNo)
                .query(`
                  SELECT
                    d.amount  AS amount,
                    d.adv_amt AS adv_amt,
                    d.dentry  AS dentry
                  FROM dbo.debt_d d
                  INNER JOIN dbo.debttrn t
                    ON d.trn_id = t.trn_id
                  WHERE t.trn_ref = @scfNo
                    AND d.doc_no  = @docNo
                `);

              if (resD.recordset.length) {
                const rec = resD.recordset[0];

                // แปลง debt_d.amount → amountVal (2 ตำแหน่ง)
                if (rec.amount != null) {
                  amountVal = parseFloat(rec.amount).toFixed(2);
                }
                // แปลง debt_d.adv_amt → advanceVal (2 ตำแหน่ง)
                if (rec.adv_amt != null) {
                  advanceVal = parseFloat(rec.adv_amt).toFixed(2);
                }
                // แปลง debt_d.dentry → dentryVal ("YYYY-MM-DD")
                if (rec.dentry instanceof Date) {
                  dentryVal = rec.dentry.toISOString().slice(0, 10);
                }
              }
            } catch (err) {
              console.error(`Error fetching debt_d for SCF=${scfNo}, DocNo=${docNo}:`, err);
            }
          }

          // 2.5.2 เติมค่าเข้า row ตามชื่อคอลัมน์ใหม่
          row['amount'] = amountVal;
          row['advance'] = advanceVal;
          row['dentry'] = dentryVal;
        }

        // 2.6 สร้างชีทใหม่จาก detailRowsRaw โดยใช้ newHeader
        const detailSheet = xlsx.utils.json_to_sheet(detailRowsRaw, { header: newHeader });
        wbFull.Sheets[detailName] = detailSheet;
      }
    }

    // --------- 3) สร้างไฟล์ For Customer (กรณีมี) ---------
    // (โค้ดเดิมของคุณ เริ่มตั้งแต่ SELECT trn_ref … ถึงอัปโหลด For Customer)
    const { recordset } = await pool.request().query(
      `SELECT trn_ref
       FROM dbo.debttrn
       WHERE trn_result IN ('COMPLETED','REJECTED')
         AND export_dd IS NULL`
    );
    const eligibleRefs = recordset.map(r => r.trn_ref);

    if (eligibleRefs.length) {
      const headerMain = Object.keys(enrichedMain[0] || {});
      const custRowsMain = enrichedMain.filter(r => eligibleRefs.includes(r['SCF Transaction No.']));
      const enrichedCust = await Promise.all(custRowsMain.map(async r => r));

      const custWb = xlsx.utils.book_new();
      const mainWS = xlsx.utils.json_to_sheet(enrichedCust, { header: headerMain });
      xlsx.utils.book_append_sheet(custWb, mainWS, mainName);

      // เอา Detail sheet (ที่เพิ่ง Enrich แล้ว) มาสร้าง For Customer
      const detailWS = wbFull.Sheets[detailName];
      if (detailWS) {
        xlsx.utils.book_append_sheet(custWb, detailWS, detailName);
      }

      const now = new Date();
      const dd = String(now.getDate()).padStart(2, '0');
      const MM = String(now.getMonth() + 1).padStart(2, '0');
      const yyyy = now.getFullYear();
      const hh = String(now.getHours()).padStart(2, '0');
      const mi = String(now.getMinutes()).padStart(2, '0');
      const ss = String(now.getSeconds()).padStart(2, '0');
      const timestamp = `${dd}-${MM}-${yyyy}_${hh}.${mi}.${ss}`;
      const custFileName = `GEC_${timestamp}.xlsx`;
      const custBuffer = xlsx.write(custWb, { type: 'buffer', bookType: 'xlsx' });
      await putFileBuffer(custBuffer, custFileName);
      console.log(`Uploaded For Customer: ${custFileName}`);

      const listSql = eligibleRefs.map(r => `'${r.replace(/'/g, "''")}'`).join(',');
      await pool.request().query(
        `UPDATE dbo.debttrn
         SET export_dd = CAST(GETDATE() AS date)
         WHERE trn_ref IN (${listSql})
           AND export_dd IS NULL`
      );
      console.log(`Updated export_dd for ${eligibleRefs.length} records`);
    } else {
      console.log('No rows qualified for For Customer');
    }
  }
}

// ----------------------------------------------------
// ฟังก์ชัน exportByResult (ปรับให้ดึง trn_reason, trn_reason_txt จาก debttrn)
// ----------------------------------------------------
async function exportByResult() {
  const pool = await getPool();

  // 1) Query แถว debttrn ที่ต้องการ (COMPLETED/REJECTED และ export_dd IS NULL)
  //    เพิ่ม trn_reason, trn_reason_txt ลงใน SELECT เพื่อใช้งานต่อ
  const { recordset: debtRows } = await pool.request().query(`
    SELECT
      t.trn_id,
      t.trn_ref,
      t.amount           AS debt_amount,
      t.trn_status_dd,
      t.trn_result,
      t.bank_tr_no       AS bank_tr_no,
      t.bank_tr_dt       AS bank_tr_dt,
      t.trn_reason       AS trn_reason,
      t.trn_reason_txt   AS trn_reason_txt
    FROM dbo.debttrn t
    WHERE t.trn_result IN ('COMPLETED','REJECTED')
      AND t.export_dd IS NULL
  `);

  for (const debtRow of debtRows) {
    const ref = debtRow.trn_ref;
    if (!ref) {
      console.warn('Missing trn_ref, skipping this row');
      continue;
    }

    // 2) Query SCF_Transactions สำหรับดึงข้อมูลอื่น ๆ (ยกเว้น 4 ฟิลด์ที่จะ override)
    const mainRes = await pool.request()
      .input('scfNo', sql.NVarChar(50), ref)
      .query(`
        SELECT
          Sponsor,
          Supplier,
          Sponsor_Customer_ID       AS [Sponsor Customer ID],
          Supplier_Customer_ID      AS [Supplier Customer ID],
          SCF_Transaction_No        AS [SCF Transaction No.],
          Transaction_Date          AS [Transaction Date],
          Maturity_Date             AS [Maturity Date],
          Sponsor_Payment_Date      AS [Sponsor Payment Date],
          Interest_Rate             AS [Interest Rate],
          Transaction_Amount        AS [Transaction Amount],
          Currency,
          Transaction_Type          AS [Transaction Type],
          Supplier_Bank_Code_Source     AS [Supplier Bank Code (Source)],
          Bank_Account_No_Source         AS [Bank Account No. (Source)],
          Supplier_Bank_Code_Destination AS [Supplier Bank Code (Destination)],
          Bank_Account_No_Destination     AS [Bank Account No. (Destination)],
          Remark,
          Current_Transaction_Status      AS [Current Transaction Status],
          -- ไม่ดึง Transaction_Result_Status, Bank_Transaction_No, Reason_Code, Reason ที่นี่
          Bank_Transaction_Date           AS [Bank Transaction Date],
          Bank_Transaction_Time           AS [Bank Transaction Time],
          adv_amt,
          int_amt,
          ffee,
          othfee,
          deposit,
          net_payment                       AS [net payment],
          amt_i,
          wht_i,
          amt_f,
          wht_f,
          sr_no,
          pur_dd,
          fix_col_dd
        FROM dbo.SCF_Transactions
        WHERE SCF_Transaction_No = @scfNo
      `);

    if (!mainRes.recordset.length) {
      console.warn(`No SCF_Transactions found for ${ref}, skipping.`);
      continue;
    }
    const mainRow = mainRes.recordset[0];

    // ฟังก์ชันช่วยแปลงวันที่และเวลา
    const fmtDate = value => {
      if (value instanceof Date) {
        return value.toISOString().slice(0, 10);
      }
      return value ? String(value) : '';
    };
    const fmtTime = value => {
      if (value instanceof Date) {
        return value.toISOString().substr(11, 8);
      }
      return value ? String(value) : '';
    };

    // 3) สร้าง object สำหรับ Main sheet (SFP_Transaction_Request)
    //    ใช้ค่าจาก debtRow.trn_result, debtRow.bank_tr_no, debtRow.trn_reason, debtRow.trn_reason_txt แทน
    const mainObj = {
      Sponsor: mainRow.Sponsor || '',
      Supplier: mainRow.Supplier || '',
      'Sponsor Customer ID': mainRow['Sponsor Customer ID'] || '',
      'Supplier Customer ID': mainRow['Supplier Customer ID'] || '',
      'SCF Transaction No.': mainRow['SCF Transaction No.'] || '',
      'Transaction Date': fmtDate(mainRow['Transaction Date']),
      'Maturity Date': fmtDate(mainRow['Maturity Date']),
      'Sponsor Payment Date': fmtDate(mainRow['Sponsor Payment Date']),
      'Interest Rate': mainRow['Interest Rate'] != null ? mainRow['Interest Rate'] : '',
      'Transaction Amount': mainRow['Transaction Amount'] != null ? parseFloat(mainRow['Transaction Amount']).toFixed(2) : '',
      Currency: mainRow.Currency || '',
      'Transaction Type': mainRow['Transaction Type'] || '',
      'Supplier Bank Code (Source)': mainRow['Supplier Bank Code (Source)'] || '',
      'Bank Account No. (Source)': mainRow['Bank Account No. (Source)'] || '',
      'Supplier Bank Code (Destination)': mainRow['Supplier Bank Code (Destination)'] || '',
      'Bank Account No. (Destination)': mainRow['Bank Account No. (Destination)'] || '',
      Remark: mainRow.Remark || '',
      'Current Transaction Status': mainRow['Current Transaction Status'] || '',
      // ดึงจาก debtRow.trn_result แทน
      'Transaction Result Status': debtRow.trn_result || '',
      // ดึงจาก debtRow.bank_tr_no แทน
      'Bank Transaction No': debtRow.bank_tr_no || '',
      'Bank Transaction Date': fmtDate(debtRow.bank_tr_dt),
      'Bank Transaction Time': fmtTime(debtRow.bank_tr_dt),
      // ดึงจาก debtRow.trn_reason, debtRow.trn_reason_txt แทน
      'Reason Code': debtRow.trn_reason || '',
      'Reason': debtRow.trn_reason_txt || '',
      adv_amt: mainRow.adv_amt != null ? mainRow.adv_amt : '',
      int_amt: mainRow.int_amt != null ? mainRow.int_amt : '',
      ffee: mainRow.ffee != null ? mainRow.ffee : '',
      othfee: mainRow.othfee != null ? mainRow.othfee : '',
      deposit: mainRow.deposit != null ? mainRow.deposit : '',
      'net payment': mainRow['net payment'] != null ? mainRow['net payment'] : '',
      amt_i: mainRow.amt_i != null ? mainRow.amt_i : '',
      wht_i: mainRow.wht_i != null ? mainRow.wht_i : '',
      amt_f: mainRow.amt_f != null ? mainRow.amt_f : '',
      wht_f: mainRow.wht_f != null ? mainRow.wht_f : '',
      sr_no: mainRow.sr_no != null ? mainRow.sr_no : '',
      pur_dd: fmtDate(mainRow.pur_dd),
      fix_col_dd: fmtDate(mainRow.fix_col_dd),
      Tenor: mainRow.pur_dd && mainRow.fix_col_dd
        ? Math.round((mainRow.fix_col_dd - mainRow.pur_dd) / (1000 * 60 * 60 * 24))
        : ''
    };

    // สร้าง Workbook ใหม่ แล้ว append Main sheet
    const wb = xlsx.utils.book_new();
    const headerMain = Object.keys(mainObj);
    const mainSheet = xlsx.utils.json_to_sheet([mainObj], { header: headerMain });
    xlsx.utils.book_append_sheet(wb, mainSheet, 'SFP_Transaction_Request');

    // 4) Query ดึงข้อมูลจากตาราง debt_d
    const detailRes = await pool.request()
      .input('trnId', sql.Int, debtRow.trn_id)
      .query(`
        SELECT
          d.doc_no          AS [Document No.],
          d.doc_dd          AS [Document Date],
          d.doc_due_dd      AS [Document Due Date],
          d.amount          AS [Document Amount],
          d.dentry          AS [dentry],
          d.adv_amt         AS [adv_amt]
        FROM dbo.debt_d d
        WHERE d.trn_id = @trnId
      `);

    // 5) เตรียม array ของแถวสำหรับ Detail sheet
    //    – ที่สำคัญคือ ใส่ค่าให้ตรงกับ headerDetail ด้านล่าง
    const detailRows = detailRes.recordset.map(r => ({
      // 5.1) คอลัมน์ “Sponsor” และ “Supplier” ให้ดึงจาก mainRow
      Sponsor: mainRow.Sponsor || '',
      Supplier: mainRow.Supplier || '',

      // 5.2) คอลัมน์ “Sponsor Customer ID” และ “Supplier Customer ID” ก็ใช้จาก mainRow
      'Sponsor Customer ID': mainRow['Sponsor Customer ID'] || '',
      'Supplier Customer ID': mainRow['Supplier Customer ID'] || '',

      // 5.3) คอลัมน์ “SCF Transaction No.” ใช้ ref (ค่าที่ส่งมาในลูป)
      'SCF Transaction No.': ref,

      // 5.4) “Supplier Code” ถ้าหมายถึงรหัส supplier (ตัวอย่างนี้ใช้ Supplier Customer ID อีกครั้ง)
      //       ถ้าในระบบของคุณมีฟิลด์อื่น เช่น mainRow.Supplier_Code ให้ปรับตรงนี้แทน
      'Supplier Code': mainRow['Supplier Customer ID'] || '',

      // 5.5) คอลัมน์ที่เหลือตามต้นฉบับ
      'Document No.': r['Document No.'] || '',
      'Document Date': fmtDate(r['Document Date']),
      'Document Due Date': fmtDate(r['Document Due Date']),

      // 5.6) “Outstanding Amount” มาจาก debtRow.debt_amount (ดึงมาจาก debttrn)
      'Outstanding Amount': r['Document Amount'] != null
        ? parseFloat(r['Document Amount']).toFixed(2)
        : '',

      // 5.7) “Transaction Amount” มาจาก mainRow
      'Transaction Amount': r['Document Amount'] != null
        ? parseFloat(r['Document Amount']).toFixed(2)
        : '',

      // 5.8) “Document Amount” มาจาก r['Document Amount'] (ฟิลด์ debt_d.amount)
      'Document Amount': r['Document Amount'] != null
        ? parseFloat(r['Document Amount']).toFixed(2)
        : '',

      // 5.9) คอลัมน์ “amount” แปลงจาก r['Document Amount'] เช่นกัน
      amount: r['Document Amount'] != null
        ? parseFloat(r['Document Amount']).toFixed(2)
        : '',

      // 5.10) คอลัมน์ “adv_amt” หรือ “advance” ใช้ r['adv_amt']
      //        แปลงเป็นตัวเลข 2 ตำแหน่ง
      advance: r['adv_amt'] != null
        ? parseFloat(r['adv_amt']).toFixed(2)
        : '',

      // 5.11) คอลัมน์ “dentry” แปลงจาก r['dentry']
      dentry: fmtDate(r['dentry'])
    }));

    // 6) กำหนด header ของ Detail sheet ตามลำดับที่ต้องการ (เหมือนต้นฉบับ + enrichment)
    const headerDetail = [
      'Sponsor',
      'Supplier',
      'Sponsor Customer ID',
      'Supplier Customer ID',
      'SCF Transaction No.',
      'Supplier Code',
      'Document No.',
      'Document Date',
      'Document Due Date',
      'Outstanding Amount',
      'Transaction Amount',
      'Document Amount',
      'amount',
      'advance',
      'dentry'
    ];

    // 7) สร้างชีทใหม่จาก detailRows และ headerDetail
    const detailSheet = xlsx.utils.json_to_sheet(detailRows, { header: headerDetail });
    xlsx.utils.book_append_sheet(wb, detailSheet, 'SFP_Transaction_Request_Detail');


    // 5) เขียน Workbook เป็น Buffer แล้วอัปโหลดไปยังโฟลเดอร์ Transaction_Result
    const buf = xlsx.write(wb, { bookType: 'xlsx', type: 'buffer' });
    const fileName = `${ref}.xlsx`;

    try {
      await putFileBuffer(buf, fileName);
      console.log(`Uploaded via SFTP: ${fileName}`);
    } catch (err) {
      console.error(`Error uploading via SFTP for ${fileName}:`, err);
      continue;
    }

    // 6) อัปเดต export_dd ใน debttrn เพื่อไม่ให้ส่งซ้ำ
    try {
      await pool.request()
        .input('trn_ref', sql.NVarChar(50), ref)
        .query(`
          UPDATE dbo.debttrn
          SET export_dd = GETDATE()
          WHERE trn_ref = @trn_ref
        `);
      console.log(`Updated export_dd for ${ref}`);
    } catch (err) {
      console.error(`Error updating export_dd for ${ref}:`, err);
    }
  }

  console.log('Finished exportByResult.');
}

async function exportNoSupplier() {
  const pool = await getPool();

  // 1) Query SCF_Transactions ที่ Reason_Code='02' หรือ Reason='No Supplier Found'
  const { recordset: rows } = await pool.request().query(`
    SELECT
      Sponsor,
      Supplier,
      Sponsor_Customer_ID       AS [Sponsor Customer ID],
      Supplier_Customer_ID      AS [Supplier Customer ID],
      SCF_Transaction_No        AS [SCF Transaction No.],
      Transaction_Date          AS [Transaction Date],
      Maturity_Date             AS [Maturity Date],
      Sponsor_Payment_Date      AS [Sponsor Payment Date],
      Interest_Rate             AS [Interest Rate],
      Transaction_Amount        AS [Transaction Amount],
      Currency,
      Transaction_Type          AS [Transaction Type],
      Supplier_Bank_Code_Source     AS [Supplier Bank Code (Source)],
      Bank_Account_No_Source         AS [Bank Account No. (Source)],
      Supplier_Bank_Code_Destination AS [Supplier Bank Code (Destination)],
      Bank_Account_No_Destination     AS [Bank Account No. (Destination)],
      Remark,
      Current_Transaction_Status      AS [Current Transaction Status],
      Transaction_Result_Status       AS [Transaction Result Status],
      Bank_Transaction_No              AS [Bank Transaction No],
      Bank_Transaction_Date            AS [Bank Transaction Date],
      Bank_Transaction_Time            AS [Bank Transaction Time],
      Reason_Code                       AS [Reason Code],
      Reason,
      adv_amt,
      int_amt,
      ffee,
      othfee,
      deposit,
      net_payment                       AS [net payment],
      amt_i,
      wht_i,
      amt_f,
      wht_f,
      sr_no,
      pur_dd,
      fix_col_dd
    FROM dbo.SCF_Transactions
    WHERE Reason_Code = '02'
       OR Reason = 'No Supplier Found'
  `);

  if (!rows.length) {
    console.log('exportNoSupplier: ไม่มีข้อมูล SCF_Transactions ที่ Reason_Code=02 หรือ Reason="No Supplier Found"');
    return;
  }

  // 2) สร้าง Workbook + Sheet ชื่อ "SFP_Transaction_Request"
  const wb = xlsx.utils.book_new();
  const fmtDate = dt => dt instanceof Date ? dt.toISOString().slice(0, 10) : (dt ? String(dt) : '');
  const fmtTime = tm => tm instanceof Date ? tm.toISOString().substr(11, 8) : (tm ? String(tm) : '');

  const exportData = rows.map(r => ({
    Sponsor: r.Sponsor || '',
    Supplier: r.Supplier || '',
    'Sponsor Customer ID': r['Sponsor Customer ID'] || '',
    'Supplier Customer ID': r['Supplier Customer ID'] || '',
    'SCF Transaction No.': r['SCF Transaction No.'] || '',
    'Transaction Date': fmtDate(r['Transaction Date']),
    'Maturity Date': fmtDate(r['Maturity Date']),
    'Sponsor Payment Date': fmtDate(r['Sponsor Payment Date']),
    'Interest Rate': r['Interest Rate'] != null ? r['Interest Rate'] : '',
    'Transaction Amount': r['Transaction Amount'] != null ? parseFloat(r['Transaction Amount']).toFixed(2) : '',
    Currency: r.Currency || '',
    'Transaction Type': r['Transaction Type'] || '',
    'Supplier Bank Code (Source)': r['Supplier Bank Code (Source)'] || '',
    'Bank Account No. (Source)': r['Bank Account No. (Source)'] || '',
    'Supplier Bank Code (Destination)': r['Supplier Bank Code (Destination)'] || '',
    'Bank Account No. (Destination)': r['Bank Account No. (Destination)'] || '',
    Remark: r.Remark || '',
    'Current Transaction Status': r['Current Transaction Status'] || '',
    'Transaction Result Status': r['Transaction Result Status'] || '',
    'Bank Transaction No': r['Bank Transaction No'] || '',
    'Bank Transaction Date': fmtDate(r['Bank Transaction Date']),
    'Bank Transaction Time': fmtTime(r['Bank Transaction Time']),
    'Reason Code': r['Reason Code'] || '',
    'Reason': r.Reason || '',
    adv_amt: r.adv_amt != null ? r.adv_amt : '',
    int_amt: r.int_amt != null ? r.int_amt : '',
    ffee: r.ffee != null ? r.ffee : '',
    othfee: r.othfee != null ? r.othfee : '',
    deposit: r.deposit != null ? r.deposit : '',
    'net payment': r['net payment'] != null ? r['net payment'] : '',
    amt_i: r.amt_i != null ? r.amt_i : '',
    wht_i: r.wht_i != null ? r.wht_i : '',
    amt_f: r.amt_f != null ? r.amt_f : '',
    wht_f: r.wht_f != null ? r.wht_f : '',
    sr_no: r.sr_no || '',
    pur_dd: fmtDate(r.pur_dd),
    fix_col_dd: fmtDate(r.fix_col_dd)
  }));

  const headerOrder = [
    'Sponsor',
    'Supplier',
    'Sponsor Customer ID',
    'Supplier Customer ID',
    'SCF Transaction No.',
    'Transaction Date',
    'Maturity Date',
    'Sponsor Payment Date',
    'Interest Rate',
    'Transaction Amount',
    'Currency',
    'Transaction Type',
    'Supplier Bank Code (Source)',
    'Bank Account No. (Source)',
    'Supplier Bank Code (Destination)',
    'Bank Account No. (Destination)',
    'Remark',
    'Current Transaction Status',
    'Transaction Result Status',
    'Bank Transaction No',
    'Bank Transaction Date',
    'Bank Transaction Time',
    'Reason Code',
    'Reason',
    'adv_amt',
    'int_amt',
    'ffee',
    'othfee',
    'deposit',
    'net payment',
    'amt_i',
    'wht_i',
    'amt_f',
    'wht_f',
    'sr_no',
    'pur_dd',
    'fix_col_dd'
  ];

  const ws = xlsx.utils.json_to_sheet(exportData, { header: headerOrder });
  xlsx.utils.book_append_sheet(wb, ws, 'SFP_Transaction_Request');

  // 3) ตั้งชื่อไฟล์แล้วอัปโหลด
  const now = new Date();
  const tsDate = String(now.getFullYear()) +
    String(now.getMonth() + 1).padStart(2, '0') +
    String(now.getDate()).padStart(2, '0') + '_' +
    String(now.getHours()).padStart(2, '0') +
    String(now.getMinutes()).padStart(2, '0') +
    String(now.getSeconds()).padStart(2, '0');
  const fileName = `NoSupplier_${tsDate}.xlsx`;
  const fileBuffer = xlsx.write(wb, { bookType: 'xlsx', type: 'buffer' });

  try {
    await putFileBuffer(fileBuffer, fileName);
    console.log(`exportNoSupplier: Uploaded file "${fileName}" with ${rows.length} rows.`);
  } catch (err) {
    console.error(`exportNoSupplier: Error uploading "${fileName}":`, err);
  }
}


// ----------------------------------------------------
// Rename processed files by appending "_Read"
// ----------------------------------------------------
async function markAsRead(files) {
  for (const fileName of files) {
    const newName = fileName.replace(/\.xlsx$/i, '') + '_Read.xlsx';
    await renameRemoteFile(fileName, newName);
    console.log(`Renamed ${fileName} to ${newName}`);
  }
}

// ----------------------------------------------------
// Main driver
// ----------------------------------------------------
async function processAllFiles() {
  try {
    // 1) ปิด connection เดิมถ้ามี (ignore error)
    try {
      await sftp.end();
      await sftpSMF.end();
    } catch (_) { }

    // 2) สร้าง connection ใหม่
    await sftp.connect(sftpConfig);
    await sftpSMF.connect(sftpSMFConfig);

    // 4) เรียกฟังก์ชัน exportNoSupplier เพื่อส่ง SCF_Transactions ที่ Reason_Code=02 หรือ Reason="No Supplier Found"
    await exportNoSupplier();

    // 5) เรียกฟังก์ชัน exportByResult เสมอ เพื่อส่ง debttrn COMPLETED/REJECTED แม้ไม่มีไฟล์ใหม่
    await exportByResult();

    // 6) ดึงไฟล์ใหม่จากโฟลเดอร์ Transaction_Request
    const rawFiles = await listRawFiles();
    if (!rawFiles.length) {
      console.log('No new files to process.');
    } else {
      // 6.1) import & insert ข้อมูลลงฐาน
      for (const f of rawFiles) {
        await processExcelFile(f);
      }
      // 6.2) update SCF_Transactions
      await updateSCFTransactionsFromDebttrn();
      // 6.3) ทำ enrichment และอัปโหลดไฟล์หลัก + For Customer
      await exportFiles(rawFiles);
      // 6.4) เรียกส่ง debttrn ใหม่อีกรอบ (optional)
      await exportByResult();
      // 6.5) เปลี่ยนชื่อไฟล์ต้นฉบับเป็น _Read.xlsx
      await markAsRead(rawFiles);
    }
  } catch (err) {
    console.error('Error in processAllFiles:', err);
  } finally {
    // 7) ปิด SFTP connection
    try {
      await sftp.end();
      await sftpSMF.end();
    } catch (_) { }
    // 8) ปิด SQL pool ถ้ามี
    if (pool) {
      try {
        await pool.close();
      } catch (_) { }
    }
  }
}

// ----------------------------------------------------
// Cron Job & Express Route
// ----------------------------------------------------
cron.schedule('*/15 * * * *', async () => {
  console.log('Cron job started...');
  await processAllFiles();
  console.log('Cron job finished.');
});

const app = express();
app.get('/run-excel-import', async (req, res) => {
  try {
    await processAllFiles();
    res.send('Import, export, exportByResult, and renaming complete.');
  } catch (err) {
    console.error('Error in manual run:', err);
    res.status(500).send('Error during processing.');
  }
});

// Update SCFTransactions From Debttrn Every 15 MIN
cron.schedule('*/15  * * * *', async () => {
  try {
    await updateSCFTransactionsFromDebttrn();
    console.log('All tasks complete.');
  } catch (err) {
    console.error('Error in cron:', err);
  }
});

const PORT = 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
